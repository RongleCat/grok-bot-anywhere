<p align="center">
  <img src="assets/hero.png" alt="Grok Bot avatars: pebble, cloud, sparkle, flower, heart, star" width="1200">
</p>

<h1 align="center">grok-bot-avatar-engine</h1>

<p align="center">
  The avatar engine behind Grok Bot: 25 shapes, 11 colors, 12 states, agent-id derivation,
  the main-bot star, bot strips, and PNG capture.
</p>

<p align="center">
  <a href="https://www.npmjs.com/package/grok-bot-avatar-engine"><img alt="npm" src="https://img.shields.io/npm/v/grok-bot-avatar-engine?color=f59312"></a>
  <a href="LICENSE"><img alt="license" src="https://img.shields.io/badge/license-MIT-blue"></a>
  <img alt="module" src="https://img.shields.io/badge/module-ESM-f59312">
</p>

---

This package ships the actual avatar runtime from the Grok Bot 0.70.2 web client, wrapped in a small,
dependency-free API. The shapes, palette, eye expressions, breathing motion, main-bot badge, and
notched silhouette are not re-drawn approximations: they are the shipping implementation.

- **Static anywhere** — generate standalone SVG strings or data URLs in Node and the browser.
- **Live in the browser** — mount animated avatars into a shadow root; eyes follow the pointer.
- **Agent identity** — derive a stable shape and color from any agent id, or override either.
- **Bot strips** — compact rows with per-bot control, nod and acknowledge gestures, PNG capture.
- **One import** — a single ESM bundle with React already inside. No peer dependencies.

> Unofficial project. Not affiliated with or endorsed by xAI. See [NOTICE](NOTICE).

## Install

```sh
npm install grok-bot-avatar-engine
```

Requires Node 18+ for static rendering. Live avatars need a browser with shadow DOM;
`capture()` and `renderAvatarPng()` additionally need canvas.

## Quick start

### Static SVG

```js
import { renderAvatarSvg, renderAvatarDataUrl } from 'grok-bot-avatar-engine';

// Shape and color derived from the agent id.
const svg = renderAvatarSvg({ agentId: '33cf1aae-3a51-452d-b761-34a6ccb62201', size: 128 });

// Explicit look, pinned theme.
const dark = renderAvatarSvg({ shape: 'cloud', color: 'blue', theme: 'dark', size: 96 });

// Ready for an <img src>.
const src = renderAvatarDataUrl({ shape: 'heart', color: 'magenta', size: 64 });
```

With `theme: 'auto'` (the default) the SVG carries a `prefers-color-scheme` rule, so named colors
adapt on their own — including inside `<img>`.

### Live avatar

```js
import { createAvatar } from 'grok-bot-avatar-engine';

const avatar = createAvatar(document.querySelector('#bot'), {
  agentId: '33cf1aae-3a51-452d-b761-34a6ccb62201',
  state: 'working',
  main: true,          // star badge + notched silhouette
  size: 160,
  theme: 'auto',
});

avatar.setState('happy');
avatar.setShape('cloud');
avatar.setColor('violet');

const png = await avatar.capture(512); // data:image/png;...
avatar.destroy();
```

The target element must have a size (pass `size`, or size it with CSS). Everything else lives in a
shadow root, so page styles cannot leak in.

### Bot strip

```js
import { createStrip } from 'grok-bot-avatar-engine';

const strip = createStrip(document.querySelector('#team'), {
  mark: 44,
  bots: [
    { id: 'main', agentId: '33cf1aae-3a51-452d-b761-34a6ccb62201', main: true },
    { id: 'ops', shape: 'hex', color: 'green', state: 'working' },
    { id: 'design', agentId: 'b6f0623e-8d7b-4c73-9c9e-52f6a7f1c001' },
  ],
});

strip.nodNeighbors();        // two adjacent bots glance at each other
strip.acknowledge('ops');    // one bot blinks and looks down
await strip.capture('main'); // PNG of a single cell
strip.destroy();
```

### Identity derivation

```js
import { resolveAvatar } from 'grok-bot-avatar-engine';

resolveAvatar('33cf1aae-3a51-452d-b761-34a6ccb62201');
// {
//   agentId: '33cf1aae-...',
//   shape: 'sparkle',
//   color: 'brown',
//   hash: 2400509875,
//   sources: { shape: 'id-default', color: 'id-default' }
// }
```

The hash is FNV-1a over the id's UTF-16 code units. Shape is drawn from the 13 default shapes and
color from the 10 default colors (`black` is never assigned automatically). Pass `shape`/`color`
(or `avatarShape`/`avatarColor`) to override either one.

## API

### Rendering

| Export | Environment | Returns |
| --- | --- | --- |
| `renderAvatarSvg(options)` | Any | SVG string |
| `renderAvatarDataUrl(options)` | Any | `data:image/svg+xml,...` |
| `renderAvatarPng(options)` | Browser | `Promise<string>` PNG data URL |
| `createAvatar(target, options)` | Browser | `AvatarHandle` |
| `createStrip(target, options)` | Browser | `StripHandle` |

`renderAvatar*` options: `agentId`, `shape`, `color`, `avatarShape`, `avatarColor`, `size`
(default 128), `ink` (override fill), `theme` (`'auto' | 'light' | 'dark'`), `id`, `fill`
(ink fraction, `(0, 1]`).

### `createAvatar` options

| Option | Type | Default | Notes |
| --- | --- | --- | --- |
| `agentId` | `string` | — | Derives shape/color when not explicit |
| `shape` | `AvatarShape` | derived | One of the 25 shapes |
| `color` | `string` | derived | Palette name or any CSS color |
| `state` | `AvatarState` | `'idle'` | See states below |
| `seed` | `string \| number` | id/shape | Animation seed |
| `id` | `string` | — | Passed to the SVG `id` |
| `main` | `boolean` | `false` | Star badge + notch |
| `follow` | `boolean` | `true` | Eyes track the pointer |
| `visible` | `boolean` | `true` | `false` freezes the canvas |
| `reducedMotion` | `boolean` | `false` | Static pose |
| `theme` | `'auto' \| 'light' \| 'dark'` | `'auto'` | Named-color resolution |
| `size` | `number` | — | Sets host width/height in px |
| `className` | `string` | — | Added to the host |
| `style` | `Partial<CSSStyleDeclaration>` | — | Applied to the host |

Handle: `update(patch)`, `setState`, `setShape`, `setColor`, `setMain`, `setVisible`,
`setReducedMotion`, `blink`, `look(direction)`, `gaze([x, y] | null)`, `setExpression`,
`restart`, `poke(x, y)`, `capture(size)`, `destroy`, and `element`.

### `createStrip` options

`bots` (array of `{ id, agentId, shape, color, state, seed, main }`), `mark` (cell edge, default
40), `theme`, `reducedMotion`, `className`.

Handle: `get(id)`, `update({ bots, mark, theme, reducedMotion })`, `nodNeighbors()`,
`acknowledge(id)`, `capture(id, size)`, `destroy`, and `element`.

### Constants and helpers

- `STATES`, `STATE_ALIASES` (`wide → listening`, `comet → streaming`), `mapState(state)`
- `SHAPES` (25), `DEFAULT_SHAPES` (13), `isShape(value)`
- `COLORS` (11), `DEFAULT_COLORS` (10), `PALETTE` (label + base/light/dark hex), `isColor(value)`
- `resolveAvatar(input)`, `hashAgentId(id)`, `colorHex(name, theme?)`, `colorCss(name)`
- `FALLBACK_INK`, `FALLBACK_SHAPE`, `AVATAR_SIZE_DEFAULT`, `AVATAR_CSS`

```text
states   idle listening thinking streaming searching working
         waiting blocked finished failed sleeping happy

shapes   blob pebble bean egg squircle tablet capsule cylinder hex gem crystal
         wedge shield dome arch cloud teardrop leaf square sparkle clover flower
         heart house star

colors   black brown red orange yellow green cyan blue violet magenta gray
```

`AVATAR_CSS` is the stylesheet used inside the shadow root. Import it only if you are rendering the
internal frame markup yourself.

## Notes

- **Bundle size** is about 797 KiB minified because the faithful runtime and its React 19 dependency
  are included. There is no practical tree-shaking within it.
- **Themes**: named colors resolve per theme. In static SVGs with `theme: 'auto'` the choice happens
  through `prefers-color-scheme` inside the SVG; live avatars resolve it on the host with a
  `light-dark`-style fallback and update when the system scheme changes. CSS colors are used verbatim.
- **CSP**: live avatars inject a `<style>` element into their shadow root, and `capture()` loads a
  `blob:` image into canvas. Allow inline styles and `img-src blob:` if you enforce a Content
  Security Policy.
- **Capture** rasterizes the painted SVG at the requested size, with a transparent background.

## Development

```sh
npm install
npm run build       # bundle src/ + runtime/ into dist/
npm test            # Node tests against the built package
npm run typecheck   # validate types/index.d.ts and its usage
npm run test:browser # Playwright-driven DOM/capture test (skips if Chromium is missing)
npm run demo        # serve demo/ at http://127.0.0.1:4173/
```

Set `PLAYWRIGHT_CHROMIUM_EXECUTABLE` or `CHROME_PATH` if the browser test cannot find a Chromium
build. `AVATAR_TEST_SHOT=/path.png` saves a screenshot of the browser test page.

Project layout: `runtime/` is the vendored Grok Bot runtime, `src/` is the wrapper and public API,
`types/` holds the hand-written declarations, `dist/` is the published bundle.

## Provenance and license

The wrapper, types, build, demo, and tests are MIT licensed. The avatar runtime under `runtime/` was
extracted from the Grok Bot 0.70.2 client and remains the property of its respective owners; the MIT
license does not grant rights to it. Read [NOTICE](NOTICE) before redistributing or using this
commercially. To build a clean-room variant, replace `runtime/` while keeping the same exports.
